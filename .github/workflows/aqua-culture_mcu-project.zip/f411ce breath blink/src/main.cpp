#include <LoRaConfig.h>
#include <Wire.h>

const int ledPin = PC13; // 定义LED连接的引脚
unsigned long previousMillis = 0; // 存储最后一次切换LED状态的时间
const long interval = 1000; // 间隔时间（毫秒）


// 创建LoRaConfig对象，传入我们选择的HardwareSerial对象
LoRaConfig lora(Serial1);

void setup() {
  Serial.begin(9600); // 开始与电脑的通信
  Serial1.begin(9600); // 与LoRa模块通信的串口
  pinMode(ledPin, OUTPUT); // 设置LED引脚为输出模式

  // 你可以在这里使用Serial1进行通信，例如发送一个测试消息
  Serial1.println("Hello LoRa");
  while (!Serial) {
    ; // 等待串行端口连接
  }

  Serial1.begin(9600); // 开始与LoRa模块的通信，确保这里的波特率与模块当前配置的波特率匹配
  lora.begin(9600); // 这里只是初始化LoRaConfig类，并不改变串口的波特率

  // 现在，我们可以开始发送配置命令了
  // 例如，改变LoRa模块的波特率到1200
  lora.changeBaudRate(1200);
  Serial.println("b rate set as 1200");

  // 修改本地地址为33
  lora.changeLocalAddress(33);
  Serial.println("adress set as 33");

  // 配置信道、功率、空速
  // 信道20（10100），功率21dBm(11)，空速9.6k（011） -> 1010011011 -> 0x29B
  lora.configureChannelPowerAirRate(0x29B);
  Serial.println("config succes");

  // 如果你需要读取配置，等待一段时间确保命令执行完毕后再进行读取
  // 例如，读取本地地址
  delay(1000); // 等待命令执行
  lora.readLocalAddress(); // 这将通过Serial打印读取到的地址
}

void loop() {
  unsigned long currentMillis = millis(); // 获取当前时间

  // 检查是否已达到切换LED状态的时间间隔
  if (currentMillis - previousMillis >= interval) {
    previousMillis = currentMillis; // 保存当前时间为下一次切换的开始时间

    // 读取LED当前的状态并反转它
    if (digitalRead(ledPin) == HIGH) {
      digitalWrite(ledPin, LOW); // 如果LED是打开的，关闭它
    } else {
      digitalWrite(ledPin, HIGH); // 如果LED是关闭的，打开它
    }
  }
  // 在这里，你可以根据需要添加更多的代码
  // 例如，定期读取RSSI值或者根据某些触发器更改LoRa配置
}
