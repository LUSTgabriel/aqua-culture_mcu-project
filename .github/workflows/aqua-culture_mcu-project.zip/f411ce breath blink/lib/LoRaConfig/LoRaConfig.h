#ifndef LoRaConfig_h
#define LoRaConfig_h

#include "Arduino.h"

class LoRaConfig {
  public:
    LoRaConfig(HardwareSerial& serial);
    void begin(long baudRate);
    void readLocalGroupNumber();
    void readLocalAddress();
    void readTargetGroupNumber();
    void readTargetAddress();
    void changeBaudRate(uint16_t baudRate);
    void changeLocalAddress(uint8_t address);
    void configureChannelPowerAirRate(uint16_t config);
    void readRSSI();
  private:
    HardwareSerial* _serial;
    void sendCommand(String command);
    String readResponse();
};

#endif
