#include "LoRaConfig.h"

LoRaConfig::LoRaConfig(HardwareSerial& serial) {
  _serial = &serial;
}

void LoRaConfig::begin(long baudRate) {
  _serial->begin(baudRate);
}

void LoRaConfig::sendCommand(String command) {
  for (int i = 0; i < command.length(); i++) {
    _serial->write(command[i]); // 使用write发送每个字符
  }
  _serial->write('\n'); // 假设命令以换行符结束
}

String LoRaConfig::readResponse() {
  String response = "";
  long startTime = millis();
  while (!_serial->available()) {
    if (millis() - startTime > 1000) { // 超时设置为1秒
      return "Timeout";
    }
  }
  while (_serial->available()) {
    char c = _serial->read();
    response += c;
  }
  return response;
}

void LoRaConfig::changeBaudRate(uint16_t baudRate) {
  String command = "8004010000";
  command += String(baudRate, HEX);
  sendCommand(command);
}

void LoRaConfig::changeLocalAddress(uint8_t address) {
  String command = "801901";
  command += String(address, HEX);
  sendCommand(command);
}

void LoRaConfig::configureChannelPowerAirRate(uint16_t config) {
  String command = "80060102";
  command += String(config, HEX);
  sendCommand(command);
}

// 实现读取功能的示例，其他读取函数可以类似实现
void LoRaConfig::readLocalAddress() {
  sendCommand("001901");
  Serial.println(readResponse());
}

// 根据需要实现其他函数...
