#ifndef TDSMeter_h
#define TDSMeter_h

#include "Arduino.h"

class TDSMeter {
public:
    TDSMeter(int pin);
    void begin();
    void update(float temperature);
    float getTDSValue(); // 已经补偿的TDS值
    float getUncompensatedTDS(); // 未经补偿的TDS值
    float getVoltage(); // 电压值
    float _compensationVoltage = 0; // 添加这行

private:
    int _pin;
    static const int SCOUNT = 30; // 采样点的数量
    int _analogBuffer[SCOUNT]; // 存储ADC值的缓冲区
    int _analogBufferIndex = 0; // 缓冲区索引
    unsigned long _analogSampleTimepoint = 0; // 上次采样时间点
    unsigned long _printTimepoint = 0; // 上次打印时间点
    float _averageVoltage = 0; // 平均电压值
    float _tdsValue = 0; // TDS值
    float _temperature = 25.0; // 默认温度
    float getCompensatedVoltage(); // 声明获取补偿电压的方法

    int getMedianNum(int bArray[], int iFilterLen); // 中值滤波函数
};

#endif
