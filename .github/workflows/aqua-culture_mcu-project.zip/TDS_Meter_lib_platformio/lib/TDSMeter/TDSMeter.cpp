#include "TDSMeter.h"

TDSMeter::TDSMeter(int pin) : _pin(pin) {}

void TDSMeter::begin() {
    pinMode(_pin, INPUT);
}

//void TDSMeter::update(float temperature) {
//    _temperature = temperature;
//    if (millis() - _analogSampleTimepoint > 40u) {
//        _analogSampleTimepoint = millis();
//        _analogBuffer[_analogBufferIndex++] = analogRead(_pin);
//        if (_analogBufferIndex == SCOUNT) _analogBufferIndex = 0;
//    }
//
//    if (millis() - _printTimepoint > 800u) {
//        _printTimepoint = millis();
//        int analogBufferTemp[SCOUNT];
//        for (int i = 0; i < SCOUNT; i++) {
//            analogBufferTemp[i] = _analogBuffer[i];
//        }
//        _averageVoltage = getMedianNum(analogBufferTemp, SCOUNT) * 5.0 / 1024.0;
//        // 这里假设未经温度补偿的TDS值等于通过某种方式计算的_tdsValue，你可能需要根据实际情况调整
//        _tdsValue = (_averageVoltage - 0.5) * 1000; // 示例计算方法
//    }
//}

void TDSMeter::update(float temperature) {
    _temperature = temperature;
    if (millis() - _analogSampleTimepoint > 40u) {
        _analogSampleTimepoint = millis();
        _analogBuffer[_analogBufferIndex++] = analogRead(_pin);
        if (_analogBufferIndex == SCOUNT) _analogBufferIndex = 0;
    }

    if (millis() - _printTimepoint > 800u) {
        _printTimepoint = millis();
        int analogBufferTemp[SCOUNT];
        for (int i = 0; i < SCOUNT; i++) {
            analogBufferTemp[i] = _analogBuffer[i];
        }
        _averageVoltage = getMedianNum(analogBufferTemp, SCOUNT) * 5.0 / 1024.0;

        // 应用温度补偿
        float compensationCoefficient = 1.0 + 0.02 * (temperature - 25.0);
        float compensationVoltage = _averageVoltage / compensationCoefficient;

        // 根据补偿后的电压计算TDS值
        _tdsValue = (133.42 * compensationVoltage * compensationVoltage * compensationVoltage
                     - 255.86 * compensationVoltage * compensationVoltage
                     + 857.39 * compensationVoltage) * 0.5;
    }
}

float TDSMeter::getCompensatedVoltage() {
    return _compensationVoltage; // 返回补偿后的电压值
}

float TDSMeter::getTDSValue() {
    return _tdsValue;
}

float TDSMeter::getUncompensatedTDS() {
    return _tdsValue; // 根据实际情况可能需要调整
}

float TDSMeter::getVoltage() {
    return _averageVoltage;
}

int TDSMeter::getMedianNum(int bArray[], int iFilterLen) {
    int bTemp[iFilterLen];
    for (int i = 0; i < iFilterLen; i++) {
        bTemp[i] = bArray[i];
    }
    for (int i = 0; i < iFilterLen - 1; i++) {
        for (int j = i + 1; j < iFilterLen; j++) {
            if (bTemp[i] > bTemp[j]) {
                int temp = bTemp[i];
                bTemp[i] = bTemp[j];
                bTemp[j] = temp;
            }
        }
    }
    if (iFilterLen % 2 == 0) {
        return (bTemp[iFilterLen / 2 - 1] + bTemp[iFilterLen / 2]) / 2;
    } else {
        return bTemp[iFilterLen / 2];
    }
}
