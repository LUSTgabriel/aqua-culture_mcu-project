#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Wire.h>
#include <TDSMeter.h>


#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 32
#define OLED_RESET -1
#define TDS_SENSOR_PIN PA0


Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);
TDSMeter tdsMeter(TDS_SENSOR_PIN); // 创建TDSMeter对象，传入传感器引脚

unsigned long previousMillis = 0; // 在全局范围内定义，用于记录上次更新时间
const unsigned long interval = 1000; // 定义更新间隔为1000毫秒（1秒）


void setup() {
  Serial.begin(115200); // 开始串行通信
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C); // 初始化显示屏
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("SSD1306 allocation failed");
    for (;;); // Don't proceed, loop forever
  }
  display.clearDisplay();
  display.setTextSize(2);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.println("TDS Meter Ready");
  display.display(); // 显示屏显示内容
  delay(1000);
  pinMode(PB9, OUTPUT); //进行一个标记，指示预加载完成
  Serial.println("serial succsessfully set");

}

void loop() {
  unsigned long currentMillis = millis();
    if (currentMillis - previousMillis >= interval) {
    previousMillis = currentMillis; // 更新上次更新时间为当前时间

  tdsMeter.update(25.0f); // 使用当前水温更新TDS值，这里假定水温为25摄氏度

  float tdsValue = tdsMeter.getTDSValue(); // 获取TDS值
  float Voltage = tdsMeter.getVoltage();

  // 准备要显示的字符串
  String voltageDisplayString = "Voltage:" + String(Voltage, 2) + "V";
  String tdsDisplayString = "TDS:" + String(tdsValue, 0) + "ppm";

    // 在OLED屏幕上输出
    display.clearDisplay(); // 清除屏幕内容
    display.setTextSize(1); // 设置文本大小以适应更多内容
    display.setTextColor(SSD1306_WHITE); // 设置文本颜色
    display.setCursor(0, 0); // 设置文本开始的位置
    display.println(voltageDisplayString); // 显示电压文本
    Serial.println(voltageDisplayString);
    display.setCursor(0, 10); // 调整位置以显示第二行
    display.println(tdsDisplayString); // 显示TDS文本
    Serial.println(tdsDisplayString);
    display.display(); // 更新显示内容
 }
 //不被延迟影响的代码在这里添加
}
